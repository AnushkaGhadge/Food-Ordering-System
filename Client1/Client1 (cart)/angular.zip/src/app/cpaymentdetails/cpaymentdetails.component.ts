import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpaymentdetails',
  templateUrl: './cpaymentdetails.component.html',
  styleUrls: ['./cpaymentdetails.component.css']
})
export class CpaymentdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
