import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vregisteraddress',
  templateUrl: './vregisteraddress.component.html',
  styleUrls: ['./vregisteraddress.component.css']
})
export class VregisteraddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
