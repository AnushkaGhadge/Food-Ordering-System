import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmenulist',
  templateUrl: './cmenulist.component.html',
  styleUrls: ['./cmenulist.component.css']
})
export class CmenulistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
