import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vpendingorders',
  templateUrl: './vpendingorders.component.html',
  styleUrls: ['./vpendingorders.component.css']
})
export class VpendingordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
