import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aadddelboy',
  templateUrl: './aadddelboy.component.html',
  styleUrls: ['./aadddelboy.component.css']
})
export class AadddelboyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
