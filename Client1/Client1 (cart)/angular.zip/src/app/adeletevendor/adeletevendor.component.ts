import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adeletevendor',
  templateUrl: './adeletevendor.component.html',
  styleUrls: ['./adeletevendor.component.css']
})
export class AdeletevendorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
