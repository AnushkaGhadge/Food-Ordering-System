import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aassigndelboy',
  templateUrl: './aassigndelboy.component.html',
  styleUrls: ['./aassigndelboy.component.css']
})
export class AassigndelboyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
