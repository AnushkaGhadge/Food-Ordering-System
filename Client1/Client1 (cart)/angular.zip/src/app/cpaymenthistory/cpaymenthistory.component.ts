import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpaymenthistory',
  templateUrl: './cpaymenthistory.component.html',
  styleUrls: ['./cpaymenthistory.component.css']
})
export class CpaymenthistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
