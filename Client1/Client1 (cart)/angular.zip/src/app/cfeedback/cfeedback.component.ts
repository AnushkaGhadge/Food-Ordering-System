import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cfeedback',
  templateUrl: './cfeedback.component.html',
  styleUrls: ['./cfeedback.component.css']
})
export class CfeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
