import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cregister',
  templateUrl: './cregister.component.html',
  styleUrls: ['./cregister.component.css']
})
export class CregisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
